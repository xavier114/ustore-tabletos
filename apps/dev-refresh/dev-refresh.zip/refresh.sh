cd /home/pi/
sudo killall xinit
sudo sh /home/pi/reload.sh
cd pyos
sudo startx
