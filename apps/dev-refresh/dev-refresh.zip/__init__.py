import pyos

def refresh(resp):
    if resp == "Yes":
        pyos.os.system("sh "+pyos.os.path.join(pyos.__file__.rstrip("pyos.pyc"), "apps/dev-refresh/refresh.sh"))

def onStart(s, a):
    pyos.GUI.YNDialog("Refresh", "Are you sure you want to REFRESH PyOS 6? This will WIPE and REINSTALL everything?", refresh).display()