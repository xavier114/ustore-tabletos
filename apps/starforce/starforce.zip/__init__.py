import pyos
import random
from math import cos, sin, pi
pygame = pyos.pygame

def onStart(s, a):
    global state, app
    state = s
    app = a
    app.immersionUI.start(pyos.Application.fullCloseCurrent)
    
def gameOver():
    font = pygame.font.Font("apps/starforce/Federation.ttf", 24)
    pygame.draw.rect(screen, (200, 200, 200), [0, 40, screen.get_width(), 40])
    screen.blit(font.render("Game Over.", 1, (20, 20, 20)), [60, 44])
    pygame.draw.rect(screen, (250, 200, 200), [0, screen.get_height()-40, screen.get_width(), 40])
    screen.blit(font.render("QUIT GAME", 1, (20, 20, 20)), [60, screen.get_height()-34])
    pygame.draw.rect(screen, (200, 200, 200), [screen.get_width()-40, 0, 40, 40])
    pygame.draw.polygon(screen, (50, 50, 50), [(screen.get_width()-35, 5), (screen.get_width()-35, 35), (screen.get_width()-5, 20)])
    pygame.display.flip()
    while True:
        evt = pygame.event.poll()
        if evt.type == pygame.MOUSEBUTTONDOWN:
            if evt.pos[0] >= screen.get_width() - 40:
                gameLoop()
                return True
            if evt.pos[1] >= screen.get_height() - 40:
                return True

def pause():
    font = pygame.font.Font("apps/starforce/Federation.ttf", 24)
    pygame.draw.rect(screen, (200, 200, 200), [0, 40, screen.get_width(), 40])
    screen.blit(font.render("PAUSED", 1, (20, 20, 20)), [60, 44])
    pygame.draw.rect(screen, (250, 200, 200), [0, screen.get_height()-40, screen.get_width(), 40])
    screen.blit(font.render("QUIT GAME", 1, (20, 20, 20)), [60, screen.get_height()-34])
    pygame.draw.rect(screen, (200, 200, 200), [screen.get_width()-40, 0, 40, 40])
    pygame.draw.polygon(screen, (50, 50, 50), [(screen.get_width()-35, 5), (screen.get_width()-35, 35), (screen.get_width()-5, 20)])
    pygame.display.flip()
    while True:
        evt = pygame.event.poll()
        if evt.type == pygame.MOUSEBUTTONDOWN:
            if evt.pos[0] >= screen.get_width() - 40:
                if evt.pos[1] <= 40:
                    return False
            if evt.pos[1] >= screen.get_height() - 40:
                return True
            

def check_events(ship):
    for ev in pygame.event.get():
        if ev.type == pygame.MOUSEBUTTONDOWN:
            if ev.pos[0] >= screen.get_width() - 40:
                if ev.pos[1] <= 40:
                    return pause()
            if ev.pos[1] >= 40:
                if ev.pos[0] >= ship.rect.topleft[0] and ev.pos[0] <= ship.rect.topleft[0]+ship.rect.width:
                    if ev.pos[1] >= ship.rect.topleft[1] and ev.pos[1] <= ship.rect.topleft[1]+ship.rect.height:
                        ship.shoot()
                        return False
            if ev.pos[0] > screen.get_width()/2:
                return 1
            if ev.pos[0] < screen.get_width()/2:
                return -1
        if ev.type == pygame.MOUSEBUTTONUP:
            return "End" 
    return None     

def gameLoop():
    ship = Ship()
    shipGroup = pygame.sprite.GroupSingle()
    ship.add(shipGroup)
    enemies = pygame.sprite.Group()
    powerups = pygame.sprite.Group()
    difficulty = 1
    
    font = pygame.font.Font("apps/starforce/Federation.ttf", 24)
    
    moveBy = 0
    clock = pygame.time.Clock()
    
    starfield = Starfield()
    
    while ship.explosion != -1:
        clock.tick(20)
        
        screen.fill([20, 20, 20])
        starfield.update(ship.speed)
        
        shipGroup.update()
        enemies.update()
        ship.shots.update()
        ship.check_shots(enemies)
        powerups.update()
        
        shipGroup.draw(screen)
        enemies.draw(screen)
        powerups.draw(screen)
        ship.shots.draw(screen)
        render_paramters(ship, font, difficulty)
        
        pygame.display.flip()
        
        update_enemies(difficulty, enemies, ship)
        check_ship_collision(ship, enemies)
        check_ship_alive(ship)
        update_powerups(ship, shipGroup, powerups)
        
        eventResult = check_events(ship)
        if type(eventResult) == int:
            moveBy = (eventResult*ship.speed)
            ship.move(moveBy, 0)
        else:
            if eventResult == True:
                return
            if eventResult == None:
                ship.move(moveBy, 0)
            if eventResult == "End":
                moveBy = 0
        difficulty = adjust_difficulty(difficulty, ship)
                
    gameOver()

def main(ui, s):
    global screen
    screen = s
    
    gameLoop()
        
def adjust_difficulty(diff, ship):
    if ship.score == 0: return diff
    if (diff <= 5 and ship.score % 10 == 0) or (diff > 5 and ship.score % 15 == 0):
        ship.score += 1
        ship.speed += 1
        diff += 1
    return diff
        
def render_paramters(ship, font, difficulty):
    #Pause button
    pygame.draw.rect(screen, (200, 200, 200), [screen.get_width()-40, 0, 40, 40])
    pygame.draw.rect(screen, (50, 50, 50), [screen.get_width()-30, 10, 5, 20])
    pygame.draw.rect(screen, (50, 50, 50), [screen.get_width()-20, 10, 5, 20])
    #Shields
    pygame.draw.rect(screen, (50, 150, 50), [0, 30, screen.get_width()-40, 10])
    pygame.draw.rect(screen, (100, 255, 100), [0, 30, ((screen.get_width()-40)/100)*ship.shields, 10])
    #Score
    screen.blit(font.render(str(ship.score), 1, (200, 200, 250)), [2, 3])
    #Difficulty
    screen.blit(font.render(str(difficulty), 1, (min(250, 150+difficulty), 150, 150)), [screen.get_width()-120, 3])
        
def check_ship_alive(ship):
    if ship.shields < 0 and ship.explosion == -2: 
        ship.die()
        
def get_intelligent(difficulty):
    rn = random.randint(0, int(2*difficulty))
    return (rn > difficulty)
        
def update_enemies(difficulty, group, ship):
    if len(group) < difficulty:
        newEnemy = Enemy((ship.speed), get_intelligent(difficulty), ship)
        newEnemy.add(group)
        
def update_powerups(ship, grp, pug):
    if random.randint(0, 500) == 125:
        PhaserPowerup(ship, grp).add(pug)
    if random.randint(0, 500) == 226:
        ShieldsPowerup(ship, grp).add(pug)
        
def check_ship_collision(ship, group):
    collided = pygame.sprite.spritecollide(ship, group, False)
    for c in collided:
        if c.explosion > -1:
            continue
        if ship.powerup_shots > 0:
            ship.powerup_shots -= 1
        ship.shields -= c.speed
        c.die()
        
def draw_regular_polygon(surface, color, sides=4, radius="max", atPos="center"):
    if atPos == "center": atPos = (surface.get_width()/2, surface.get_height()/2)
    if radius == "max": radius = min(surface.get_width(), surface.get_height()) - 20
    vertices = []
    s = 0
    while s < sides:
        vertices.append([radius * cos(2*pi*s/sides) + atPos[0], radius * sin(2*pi*s/sides) + atPos[1]])
        s += 1
    pygame.draw.polygon(surface, color, vertices)
        
class Ship(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([60, 60], pygame.SRCALPHA)
        self.rect = self.image.get_rect()
        self.rect.move_ip((screen.get_width()/2)-30, screen.get_height()-70)
        
        self.speed = 3
        self.shields = 100
        self.score = 0
        
        self.explosion = -2
        
        self.powerup_shots = 0
        
        self.maintain = False
        self.shots = pygame.sprite.Group()
        
    def getPos(self): return self.rect.center
    
    def die(self):
        self.explosion = 20
        
    def death_loop(self):
        clock = pygame.time.Clock()
        color = (250, 139, 27)
        radius = 30
        while radius <= 180:
            clock.tick(10)
            pygame.draw.circle(screen, color, self.rect.center, radius)
            pygame.draw.circle(screen, (color[0]-10, color[1]-10, color[2]-10), self.rect.center, radius/2)
            pygame.draw.circle(screen, (color[0]-20, color[1]-20, color[2]-20), self.rect.center, radius/4)
            radius += 10
            pygame.display.flip()
    
    def update(self, *args):
        self.draw()
        if self.maintain and len(self.shots) <= self.powerup_shots:
            if self.powerup_shots == 0:
                Shot(self, 40, self.rect.center[0]-3).add(self.shots)
            else:
                s = 0
                while s <= self.powerup_shots:
                    Shot(self, 30, self.rect.topleft[0]+((self.rect.width/self.powerup_shots)*s)).add(self.shots)
                    s += 1
        if self.explosion > -1:
            self.explosion -= 1
            if self.speed > 0:
                self.speed -= 1
        if self.explosion == -1:
            self.kill()
            self.death_loop()
            
    def shoot(self):
        self.maintain = not self.maintain
        
    def move(self, x, y):
        if self.rect.center[0]+x < 0 or self.rect.center[0]+x > screen.get_width(): return
        self.rect.center = (self.rect.center[0]+x, self.rect.center[1]+y)
        
    def check_shots(self, enemies):
        for s in self.shots:
            c = pygame.sprite.spritecollideany(s, enemies)
            if c == None or c.explosion != -2:
                continue
            if c.explosion < -1:
                c.die()
                self.score += 1
            if s.explosion == -2:
                s.explode()
        
    def draw(self):
        self.image.fill([0, 0, 0, 0])
        c = (30, 30)
        sc = self.getPos()
        if self.shields > 5:
            pygame.draw.circle(self.image, (100, 100, 200, 50+self.shields), c, 30)
        else:
            pygame.draw.circle(self.image, (100, 100, 200), c, 30, 2)
        pygame.draw.polygon(self.image, (150, 150, 150), [(c[0]-25, c[1]+25), (c[0], c[1]-25), (c[0]+25, c[1]+25)])
        pygame.draw.polygon(self.image, (50, 50, 50), [(c[0]-10, c[1]+30), c, (c[0]+10, c[1]+30)])
        if self.shields > 0:
            pygame.draw.polygon(screen, (250, 139, 27), [(sc[0]-(15-self.speed), sc[1]+30), (sc[0], sc[1]+30+self.speed), (sc[0]+(15-self.speed), sc[1]+30)])
        if self.explosion > -1:
            pygame.draw.rect(self.image, (250, 139, 27), [random.randint(-5, self.rect.width), random.randint(-5, self.rect.height), random.randint(5, 15), random.randint(5, 15)])
            
class Shot(pygame.sprite.Sprite):
    def __init__(self, ship, speed, pos):
        pygame.sprite.Sprite.__init__(self)
        self.speed = speed
        self.image = pygame.Surface((6, 8))
        self.rect = self.image.get_rect()
        self.rect.move_ip(pos, (ship.rect.topleft[1]-8))
        self.image.fill([100, 100, 250])
        
        self.explosion = -2
        
    def update(self, *args):
        if self.explosion > -2:
            pygame.draw.circle(screen, (100, 100, 250), self.rect.center, (10-self.explosion))
            self.explosion -= 1
            if self.explosion == -1:
                self.kill()
        else:
            self.move(0, -self.speed)
        if self.rect.topleft[1] < -10:
            self.kill()
            
    def move(self, x, y):
        self.rect.center = (self.rect.center[0]+x, self.rect.center[1]+y)
        
    def explode(self):
        self.explosion = 3

class Enemy(pygame.sprite.Sprite):
    def __init__(self, speed, intelligent, ship):
        pygame.sprite.Sprite.__init__(self)
        self.target = ship
        self.image = pygame.Surface([40, 40], pygame.SRCALPHA)
        self.rect = self.image.get_rect()
        self.rect.move_ip(random.randint(0, screen.get_width()), -80)
        self.last_color = random.randint(150, 250)
        self.sides = random.randint(4, 8)
        self.explosion = -2
        self.speed = speed
        if ship.explosion != -2: intelligent = False
        self.intelligent = intelligent
        self.intel_pos = (((self.target.rect.center[0]-self.rect.center[0]))/random.randint(24, 48), ((self.target.rect.center[1]-self.rect.center[1]))/random.randint(24, 48))
        
    def get_next_color(self):
        inc = random.randint(1, 5)
        if self.last_color + inc >= 255:
            self.last_color = random.randint(150, 250)
        else:
            self.last_color += inc
        return self.last_color
    
    def die(self):
        self.explosion = 10
        
    def move(self, x, y):
        self.rect.center = (self.rect.center[0]+x, self.rect.center[1]+y)
        
    def draw(self):
        self.image.fill([0, 0, 0, 0])
        if self.explosion > -1:
            pygame.draw.rect(self.image, (250, 139, 27), [random.randint(-5, self.rect.width), random.randint(-5, self.rect.height), random.randint(5, 20), random.randint(5, 20)])
        else:
            draw_regular_polygon(self.image, (self.get_next_color(), 100, 100), self.sides)
        
    def update(self, *args):
        self.draw()
        if self.explosion > -1:
            self.explosion -= 1
        if self.explosion == -1:
            self.kill()
        if self.explosion <= -1:
            if self.intelligent == False:
                self.move(0, self.speed)
            else:
                self.move(self.intel_pos[0], self.intel_pos[1])
            if self.rect.topleft[1] > screen.get_height():
                self.kill()
                
class PhaserPowerup(pygame.sprite.Sprite):
    def __init__(self, ship, shipGrp):
        pygame.sprite.Sprite.__init__(self)
        self.ship = ship
        self.grp = shipGrp
        self.image = pygame.Surface([40, 40], pygame.SRCALPHA)
        self.rect = self.image.get_rect()
        
        self.animation = -2
        
        self.image.fill([0, 0, 0, 0])
        pygame.draw.circle(self.image, (250, 250, 250), (20, 20), 20)
        pygame.draw.circle(self.image, (100, 250, 100), (20, 20), 20, 3)
        pygame.draw.rect(self.image, (100, 100, 250), (17, 16, 6, 8))
        
        self.rect.move_ip(random.randint(0, screen.get_width()-40), -40)
        
    def update(self, *args):
        if self.animation == -2:
            self.rect.center = (self.rect.center[0], self.rect.center[1]+5)
        if pygame.sprite.spritecollideany(self, self.grp) and self.animation == -2:
            self.animation = 10
            self.ship.powerup_shots += 1
        if self.animation > -2:
            self.animation -= 1
            pygame.draw.circle(self.image, (100, 250, 100), (20, 20), 2*(10-self.animation))
            if self.animation <= -1:
                self.kill()
            
class ShieldsPowerup(pygame.sprite.Sprite):
    def __init__(self, ship, shipGrp):
        pygame.sprite.Sprite.__init__(self)
        self.ship = ship
        self.grp = shipGrp
        self.image = pygame.Surface([40, 40], pygame.SRCALPHA)
        self.rect = self.image.get_rect()
        
        self.animation = -2
        
        self.image.fill([0, 0, 0, 0])
        pygame.draw.circle(self.image, (250, 250, 250), (20, 20), 20)
        pygame.draw.circle(self.image, (100, 250, 100), (20, 20), 20, 3)
        pygame.draw.rect(self.image, (100, 250, 100), (17, 14, 6, 12))
        pygame.draw.rect(self.image, (100, 250, 100), (14, 17, 12, 6))
        
        self.rect.move_ip(random.randint(0, screen.get_width()-40), -40)
        
    def update(self, *args):
        if self.animation == -2:
            self.rect.center = (self.rect.center[0], self.rect.center[1]+5)
        if pygame.sprite.spritecollideany(self, self.grp) and self.animation == -2:
            self.animation = 10
            if self.ship.shields == 100: return
            if 100-self.ship.shields < 10:
                self.ship.shields += (100-self.ship.shields)
            else:
                self.ship.shields += 10
        if self.animation > -2:
            self.animation -= 1
            pygame.draw.circle(self.image, (100, 250, 100), (20, 20), 2*(10-self.animation))
            if self.animation <= -1:
                self.kill()

class Starfield(object):
    def __init__(self):
        self.stars = 0
        self.data = []
        
    def update(self, speed):
        for star in self.data:
            if star[1] > screen.get_height()+10:
                self.data.remove(star)
            star[1] += speed
            pygame.draw.circle(screen, (250, 250, 250, star[2]), (star[0], star[1]), star[3])
        if len(self.data) < random.randint(len(self.data)-2, len(self.data)+4):
            self.data.append([random.randint(0, screen.get_width()), -10, random.randint(50, 250), random.randint(1, 3)])