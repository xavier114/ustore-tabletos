import pyos

def onStart(s, a):
    pyos.GUI.OKDialog("Test App", "This package is used to test app install/uninstall.").display()