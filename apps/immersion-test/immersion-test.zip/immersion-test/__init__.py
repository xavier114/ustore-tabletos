import pyos

def onStart(s, a):
    global state, pygame
    pygame = pyos.pygame
    state = s
    a.immersionUI.start()
    
def immerse(ui, screen):
    exit = False
    font = state.getFont().get(20)
    clock = pygame.time.Clock()
    screen.fill([50, 50, 50])
    draw = False
    while True:
        clock.tick(20)
        pygame.display.flip()
        pygame.draw.rect(screen, (250, 200, 200), [0, state.getGUI().height-40, state.getGUI().width, 40])
        screen.blit(font.render("Click to Exit", 1, (20, 20, 20)), [10, state.getGUI().height-32])
        event = pygame.event.poll()
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.pos[1] < state.getGUI().height - 40:
                draw = not draw
            else:
                return
        if event.type == pygame.MOUSEMOTION and draw:
            pygame.draw.circle(screen, (200, 200, 250), event.pos, 4)