import pyos
import urllib2
import json
from urllib import urlencode

def onStart(s, a):
    global state, app
    state = s
    app = a
    Forum()
    
def internet_on():
    try:
        urllib2.urlopen('http://www.google.com/', timeout=5)
        return True
    except urllib2.URLError: pass
    return False

def getPostCount():
    try:
        return json.loads(str(unicode(urllib2.urlopen("http://post10forum.appspot.com/api?q=getpostcount").read(), errors="ignore")))["count"]
    except:
        return 0

def getPost(n):
    try:
        return json.loads(str(unicode(urllib2.urlopen("http://post10forum.appspot.com/api?q=getpost&d="+str(n)).read(), errors="ignore")))["post"]
    except:
        return ["Error", "Could not load from the forum", "local"]
    
def getAllPosts():
    posts = []
    num = getPostCount()
    p = 0
    while p < num:
        posts.append(getPost(p))
        p += 1
    return posts

def postNew(post):
    values = {'title': post[0],
              'post': post[1],
              'author': "pyos_app" }

    data = urlencode(values)
    urllib2.urlopen(urllib2.Request('http://post10forum.appspot.com/', data))

class Post(pyos.GUI.Container):
    def __init__(self, post):
        super(Post, self).__init__((0, 0), color=state.getColorPalette().getColor("background"), width=forum.postScroller.container.width, height=100,
                                   border=1, borderColor=(20, 20, 20))
        self.title = pyos.GUI.Text((2, 2), post[0], state.getColorPalette().getColor("item"), 18)
        self.content = pyos.GUI.MultiLineText((2, 20), self.removeBracketedText(post[1]), state.getColorPalette().getColor("item"), 14, width=self.width-4, height=80)
        self.addChild(self.title)
        self.addChild(self.content)
        
    def removeBracketedText(self, txt):
        start = txt.find('[')
        end = txt.find(']')
        while start != -1 and end != -1:
            if start != -1 and end != -1:
                txt = txt[:start] + txt[end+1:]
            start = txt.find('[')
            end = txt.find(']')
        return txt.strip(" ")
        
class NewPost(pyos.GUI.Overlay):
    def __init__(self):
        super(NewPost, self).__init__((0, app.ui.height-160), width=app.ui.width, height=160)
        self.container.border = 1
        self.titlePrompt = pyos.GUI.Text((0, 1), "Title: ", state.getColorPalette().getColor("item"), 18)
        self.titleEntry = pyos.GUI.TextEntryField((self.titlePrompt.width, 0), width=self.width-self.titlePrompt.width, height=20, slideUp=True)
        self.textEntry = pyos.GUI.MultiLineTextEntryField((0, 20), width=self.width, height=100, slideUp=True)
        self.postBtn = pyos.GUI.Button((0, 120), "Post", (200, 250, 200), (20, 20, 20), 24, width=self.width, height=40,
                                       onClick=self.post)
        self.addChild(self.titlePrompt)
        self.addChild(self.titleEntry)
        self.addChild(self.textEntry)
        self.addChild(self.postBtn)
        
    def post(self):
        state.getGUI().displayStandbyText("Posting...")
        postNew([self.titleEntry.getText(), self.textEntry.getText()])
        forum.load()
        self.hide()
    
class Forum(object):
    def __init__(self):
        global forum
        forum = self
        self.title = pyos.GUI.Text((0, 6), "10 Post Forum", state.getColorPalette().getColor("item"), 24)
        self.refreshBtn = pyos.GUI.Button((app.ui.width-60, 0), "Refresh", (100, 200, 100), (20, 20, 20), 16, width=60, height=40,
                                          onClick=self.load)
        self.postScroller = pyos.GUI.ListScrollableContainer((0, 40), width=app.ui.width, height=app.ui.height-80, color=state.getColorPalette().getColor("background"),
                                                             scrollAmount=100)
        self.newPostBtn = pyos.GUI.Button((0, app.ui.height-40), "Compose New Post", (200, 250, 200), (20, 20, 20), 24, width=app.ui.width, height=40,
                                          onClick=self.displayNewPost)
        
        app.ui.addChild(self.title)
        app.ui.addChild(self.refreshBtn)
        app.ui.addChild(self.postScroller)
        app.ui.addChild(self.newPostBtn)
        
        self.load()
        
    def displayNewPost(self):
        NewPost().display()
        
    def load(self):
        state.getGUI().displayStandbyText("Loading...")
        self.postScroller.clearChildren()
        if not internet_on():
            self.postScroller.addChild(pyos.GUI.Text((0, 0), "No Internet Conntection", state.getColorPalette().getColor("error"), 18))
            return
        for post in getAllPosts():
            self.postScroller.addChild(Post(post))
            
        
