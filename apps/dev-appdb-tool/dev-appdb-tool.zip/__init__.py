import pyos
from shutil import copy2

def onStart(s, a):
    global state, app, dadbt
    state = s
    app = a
    dadbt = DADBTool()
    
class DADBTool(object):
    def __init__(self):
        self.db = app.dataStore
        self.repoLoc = None
        
        self.rfCont = pyos.GUI.Container((0, 0), width=app.ui.width, height=40,
                                         onClick=self.presentDBSelDialog)
        self.rfCont.SKIP_CHILD_CHECK = True
        self.rfIcon = pyos.GUI.Image((0, 0), surface=state.getIcons().getLoadedIcon("folder"))
        self.rfText = pyos.GUI.Text((42, 10), "Select Repository", pyos.DEFAULT, 20)
        self.rfCont.addChildren(self.rfIcon, self.rfText)
        
        self.appsCont = pyos.GUI.ListScrollableContainer((0, 40), width=app.ui.width, height=app.ui.height-40, scrollAmount=40)
        
        app.ui.addChildren(self.rfCont, self.appsCont)
        
        self.update()
        
    def selectDB(self, path):
        self.repoLoc = path
        self.db["repo"] = path
        self.update()
        
    def presentDBSelDialog(self):
        state.getApplicationList().getApp("files").getModule().FolderPicker((0, 0), width=app.ui.width, height=app.ui.height,
                                                                            onSelect=self.selectDB).display()
        
    def genUAppEntry(self, app, manifest):
        cont = pyos.GUI.Container((0, 0), width=self.appsCont.container.width, height=40, border=1)
        cont.data["app"] = app
        ic = pyos.GUI.Image((0, 0), surface=(app.getIcon() if app.getIcon() else state.getIcons().getLoadedIcon("unknown")))
        txt = pyos.GUI.Text((42, 10), app.title, pyos.DEFAULT, 20)
        btn = pyos.GUI.Button((cont.width-60, 0), "Transfer", state.getColorPalette().getColor("lighter:background"), width=60, height=40,
                              onClick=self.transferAsk, onClickData=(manifest["apps_dir"], app, manifest))
        cont.addChildren(ic, txt, btn)
        return cont
        
    def getDBApp(self, name, appdir):
        mfstf = open(pyos.os.path.join(self.repoLoc, appdir, name, "app.json"), "rU")
        mfst = pyos.json.loads(str(unicode(mfstf.read(), errors="ignore")))
        mfstf.close()
        return {
                "name": name,
                "path": pyos.os.path.join(self.repoLoc, appdir, name),
                "manifest": mfst
                }
        
    def getAppIconPath(self, app):
        icon = app.parameters["icon"]
        try:
            p = pyos.os.path.join(state.getIcons().rootPath, state.getIcons().icons[icon]) 
            if pyos.os.path.exists(p): return False
            return p
        except:
            if pyos.os.path.exists(icon):
                return icon
            if pyos.os.path.exists(pyos.os.path.join("res/icons/", icon)):
                return pyos.os.path.join("res/icons/", icon)
            if pyos.os.path.exists(pyos.os.path.join(app.location, icon)):
                return pyos.os.path.join(app.location, icon)
            return False
        
    def transfer(self, appdir, lapp, manifest, resp):
        if resp != "OK": return
        state.getGUI().displayStandbyText("Transferring app...")
        location = pyos.os.path.join(self.repoLoc, appdir, lapp.name)
        if not pyos.os.path.exists(location):
            pyos.os.mkdir(location)
        zf = pyos.ZipFile(pyos.os.path.join(location, lapp.name+".zip"), "w")
        for item in pyos.os.listdir(lapp.location):
            zf.write(pyos.os.path.join(lapp.location, item), item)
        zf.close()
        copy2(pyos.os.path.join(lapp.location, "app.json"), location)
        if lapp.getIcon() != False:
            ic = self.getAppIconPath(lapp)
            if ic != False:
                copy2(ic, pyos.os.path.join(location, "icon.png"))
        if lapp.name not in manifest["apps"]:
            manifest["apps"].append(lapp.name)
        mf = open(pyos.os.path.join(self.repoLoc, "apps.json"), "w")
        pyos.json.dump(manifest, mf)
        mf.close()
        pyos.GUI.OKDialog("Finished", "The application "+lapp.name+" was transferred to the repository.").display()
        self.update()
        
    def transferAsk(self, appdir, lapp, manifest):
        pyos.GUI.OKCancelDialog("Transfer", "The application in the repository will be overwritten.", self.transfer, (appdir, lapp, manifest)).display()
        
    def update(self):
        self.appsCont.clearChildren()
        if self.db.get("repo", None):
            self.repoLoc = self.db.get("repo") if pyos.os.path.exists(self.db.get("repo")) else None
        if self.repoLoc == None:
            self.rfText.setText("Select Repository")
            return
        else:
            self.rfText.setText("Repo: .."+self.repoLoc[self.repoLoc.rfind("/"):])
            
        mf = open(pyos.os.path.join(self.repoLoc, "apps.json"), "rU")
        manifest = pyos.json.loads(str(unicode(mf.read(), errors="ignore")))
        mf.close()
        
        upgrades = []
        try:
            for appn in manifest["apps"]:
                if appn in state.getApplicationList().applications.keys():
                    lapp = state.getApplicationList().getApp(appn)
                    rapp = self.getDBApp(appn, manifest["apps_dir"])
                    if lapp.version > rapp["manifest"]["version"]:
                        upgrades.append((lapp, rapp))
                        self.appsCont.addChild(self.genUAppEntry(lapp, manifest))
            for appn in state.getApplicationList().applications.keys():
                if appn not in manifest["apps"]:
                    lapp = state.getApplicationList().getApp(appn)
                    upgrades.append((lapp, None))
                    self.appsCont.addChild(self.genUAppEntry(lapp, manifest))
        except:
            pyos.GUI.ErrorDialog("The application repository manifest file is invalid.").display()
            self.repoLoc = None
            self.rfText.setText("Select Repository")
        